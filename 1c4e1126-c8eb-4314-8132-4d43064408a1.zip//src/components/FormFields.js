export default function FormFields({ data, setData }) {
  const handleSubmit = () => {
    if (!data.firstName || !data.lastName) {
      alert("Please fill First & Last Name");
      return;
    }
    alert("Submitted successfully!");
    console.log("Final Data:", data);
  };

  return (
    <div className="bg-white rounded-3xl shadow-2xl p-12 border border-gray-100">
      <h2 className="text-3xl font-bold text-gray-900 mb-10">
        Your Information (You can edit)
      </h2>
      <div className="grid md:grid-cols-2 gap-8">
        {Object.keys(data).map((key) => (
          <div key={key}>
            <label className="block text-lg font-medium text-gray-700 mb-3">
              {key
                .replace(/([A-Z])/g, " $1")
                .replace(/^./, (s) => s.toUpperCase())}
            </label>
            <input
              type={key.includes("Date") ? "date" : "text"}
              value={data[key]}
              onChange={(e) => setData({ ...data, [key]: e.target.value })}
              className="w-full px-6 py-5 text-lg border-2 border-gray-300 rounded-xl focus:border-blue-500 focus:ring-4 focus:ring-blue-100 transition"
              placeholder={key === "address" ? "123 Main St, Austin, TX" : ""}
            />
          </div>
        ))}
      </div>
      <div className="mt-12 text-right">
        <button
          onClick={handleSubmit}
          className="px-16 py-6 bg-gradient-to-r from-blue-600 to-indigo-700 text-white text-2xl font-bold rounded-2xl shadow-2xl hover:shadow-3xl transform hover:scale-105 transition"
        >
          Submit Application
        </button>
      </div>
    </div>
  );
}
