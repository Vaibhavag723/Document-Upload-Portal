import { Upload, CheckCircle, XCircle, Loader2 } from "lucide-react";
import { processLicense } from "../lib/ocr";

export default function DocumentUploadZone({
  status,
  setStatus,
  setProgress,
  onProcessed,
}) {
  const handleFile = async (file) => {
    if (!file) return;

    const valid = [
      "application/pdf",
      "image/jpeg",
      "image/png",
      "text/plain",
    ].includes(file.type);
    if (!valid) {
      setStatus("error");
      return;
    }

    setStatus("uploading");
    setProgress(40);

    setTimeout(async () => {
      setStatus("processing");
      setProgress(70);

      try {
        const text = await processLicense(file);
        const extracted = extractData(text);
        onProcessed(extracted);
      } catch {
        setStatus("error");
      }
    }, 1200);
  };

  const extractData = (text) => {
    const upper = text.toUpperCase();
    const lines = upper.split("\n");

    const data = {};
    const nameLine = lines.find(
      (l) => l.includes("NAME") || /[A-Z]{2,}\s+[A-Z]{2,}/.test(l)
    );
    if (nameLine) {
      const parts = nameLine
        .replace(/NAME[:\s]*/gi, "")
        .trim()
        .split(/\s+/);
      data.lastName = parts[0] || "";
      data.firstName = parts.slice(1).join(" ");
    }

    const license = upper.match(/DL\s*[:#]?\s*([A-Z0-9-]{5,})/);
    if (license) data.licenseNo = license[1];

    const dob = upper.match(
      /(DOB|DATE OF BIRTH)[:\s]*(\d{1,2}[\/-]\d{1,2}[\/-]\d{2,4})/
    );
    if (dob) data.dob = dob[2];

    const exp = upper.match(
      /(EXP|EXPIRES)[:\s]*(\d{1,2}[\/-]\d{1,2}[\/-]\d{2,4})/
    );
    if (exp) data.expiryDate = exp[2];

    const addr = lines.find((l) => /\d{3,}.*[A-Z]/.test(l));
    if (addr) data.address = addr.trim();

    return data;
  };

  return (
    <div
      onDrop={(e) => {
        e.preventDefault();
        handleFile(e.dataTransfer.files[0]);
      }}
      onDragOver={(e) => e.preventDefault()}
      className="relative bg-white rounded-3xl shadow-2xl border-4 border-dashed border-gray-300 p-20 text-center hover:border-blue-500 transition-all cursor-pointer"
    >
      {status === "idle" && (
        <>
          <Upload className="w-24 h-24 mx-auto text-gray-400 mb-6" />
          <h3 className="text-3xl font-bold text-gray-800">
            Drop License Here
          </h3>
          <p className="text-gray-500 text-lg mt-3">
            or click to upload (PDF, JPG, PNG)
          </p>
          <input
            type="file"
            accept=".pdf,.jpg,.jpeg,.png,.txt"
            onChange={(e) =>
              e.target.files?.[0] && handleFile(e.target.files[0])
            }
            className="absolute inset-0 opacity-0 cursor-pointer"
          />
        </>
      )}
      {status === "uploading" && (
        <Loader2 className="w-20 h-20 mx-auto animate-spin text-blue-600" />
      )}
      {status === "processing" && (
        <div className="text-2xl text-indigo-600 font-medium">
          Reading license...
        </div>
      )}
      {status === "success" && (
        <div className="flex items-center gap-4 text-green-600 text-2xl">
          <CheckCircle className="w-12 h-12" /> Auto-filled!
        </div>
      )}
      {status === "error" && (
        <div className="text-red-600 text-2xl flex items-center gap-4">
          <XCircle className="w-12 h-12" /> Failed to read
        </div>
      )}
    </div>
  );
}
