import { useState, useEffect } from "react";
import {
  CheckCircle,
  FileText,
  Calendar,
  User,
  MapPin,
  UploadCloud,
} from "lucide-react";
import "./styles.css";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

export default function App() {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    licenseNo: "",
    dob: null,
    expiryDate: null,
    address: "",
  });

  const [uploadedDocs, setUploadedDocs] = useState({
    licenseFront: null,
    licenseBack: null,
    panCard: null,
    aadhaarFront: null,
    aadhaarBack: null,
    salarySlip: null,
    form16: null,
    bankStatement: null,
    cancelledCheque: null,
    noc: null,
  });

  useEffect(() => {
    const saved = localStorage.getItem("documentPortalData");
    if (saved) {
      const data = JSON.parse(saved);
      setFormData(data.formData || formData);
      setUploadedDocs(data.uploadedDocs || uploadedDocs);
    }
  }, []);

  // Save to localStorage whenever anything changes
  useEffect(() => {
    localStorage.setItem(
      "documentPortalData",
      JSON.stringify({ formData, uploadedDocs })
    );
  }, [formData, uploadedDocs]);

  // Handle file upload with instant UI update
  const handleFileUpload = (key, file) => {
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const fileData = {
        name: file.name,
        size: (file.size / 1024).toFixed(1) + " KB",
        type: file.type,
        data: reader.result,
        uploadedAt: new Date().toLocaleString(),
      };

      setUploadedDocs((prev) => ({
        ...prev,
        [key]: fileData,
      }));
    };
    reader.readAsDataURL(file);
  };

  // Count how many documents are uploaded
  const totalDocs = Object.keys(uploadedDocs).length;
  const uploadedCount = Object.values(uploadedDocs).filter(Boolean).length;
  const progress =
    totalDocs > 0 ? Math.round((uploadedCount / totalDocs) * 100) : 0;

  // Document Card Component
  const DocCard = ({ title, id, required = false }) => {
    const file = uploadedDocs[id];
    const isUploaded = !!file;

    return (
      <div
        className={`rounded-2xl p-6 flex items-center gap-5 transition-all border-2 shadow-md
        ${
          isUploaded
            ? "bg-green-50 border-green-500 shadow-green-200"
            : "bg-white border-gray-300 hover:border-gray-400"
        }`}
      >
        {/* Icon */}
        <div
          className={`p-4 rounded-full transition-all ${
            isUploaded ? "bg-green-200" : "bg-gray-100"
          }`}
        >
          {isUploaded ? (
            <CheckCircle className="w-9 h-9 text-green-700" />
          ) : (
            <UploadCloud className="w-9 h-9 text-gray-500" />
          )}
        </div>

        {/* Text */}
        <div className="flex-1">
          <p className="font-bold text-gray-800 text-lg">
            {title} {required && <span className="text-red-600">*</span>}
          </p>
          {isUploaded ? (
            <div>
              <p className="text-green-700 font-medium text-sm">{file.name}</p>
              <p className="text-xs text-green-600">{file.size} • Uploaded</p>
            </div>
          ) : (
            <p className="text-gray-500 text-sm">Click to upload</p>
          )}
        </div>

        {/* Upload Button */}
        <label className="cursor-pointer">
          <div
            className={`px-8 py-4 rounded-xl font-bold text-white transition-all transform hover:scale-105
            ${
              isUploaded
                ? "bg-emerald-600 hover:bg-emerald-700"
                : "bg-gradient-to-r from-blue-600 to-indigo-700 hover:from-blue-700 hover:to-indigo-800"
            }`}
          >
            {isUploaded ? "Change" : "Upload"}
          </div>
          <input
            type="file"
            accept="image/*,.pdf"
            className="hidden"
            onChange={(e) =>
              e.target.files?.[0] && handleFileUpload(id, e.target.files[0])
            }
          />
        </label>
      </div>
    );
  };

  return (
    <>
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 bg-gradient-to-r from-blue-900 to-indigo-900 text-white shadow-2xl z-50">
        <div className="max-w-7xl mx-auto px-8 py-6 flex justify-between items-center">
          <div className="flex items-center gap-5">
            <div className="bg-white text-blue-900 font-bold text-3xl w-16 h-16 rounded-full flex items-center justify-center">
              GoI
            </div>
            <h1 className="text-3xl font-bold">Document Upload Portal</h1>
          </div>
          <div className="flex items-center gap-8 text-lg">
            <span>English | हिंदी</span>
            <button className="bg-white text-blue-900 px-8 py-3 rounded-lg font-bold hover:bg-gray-100">
              Login
            </button>
          </div>
        </div>
      </header>

      <div className="pt-32 min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="max-w-7xl mx-auto px-8 py-12">
          {/* Progress Section */}
          <div className="bg-white rounded-3xl shadow-2xl p-12 mb-12">
            <div className="flex flex-col lg:flex-row justify-between items-center gap-10">
              <div>
                <h2 className="text-5xl font-extrabold text-gray-800">
                  Hello, Applicant!
                </h2>
                <p className="text-xl text-gray-600 mt-6">
                  Upload all required documents and fill the form below.
                  <br />
                  <span className="text-red-600 font-bold">
                    {uploadedCount} of {totalDocs} documents uploaded
                  </span>
                </p>
              </div>
              <div className="text-center">
                <div className="relative">
                  <svg className="w-56 h-56 transform -rotate-90">
                    <circle
                      cx="112"
                      cy="112"
                      r="100"
                      stroke="#e5e7eb"
                      strokeWidth="24"
                      fill="none"
                    />
                    <circle
                      cx="112"
                      cy="112"
                      r="100"
                      stroke="#10b981"
                      strokeWidth="24"
                      fill="none"
                      strokeDasharray={`${6.28 * progress} 628`}
                      className="transition-all duration-1000 ease-out"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-8xl font-bold text-green-600">
                      {progress}%
                    </span>
                  </div>
                </div>
                <p className="text-3xl font-bold text-gray-700 mt-6">
                  Complete
                </p>
              </div>
            </div>
          </div>

          {/* Document Upload Section */}
          <div className="bg-white rounded-3xl shadow-2xl p-12 mb-12">
            <h3 className="text-4xl font-bold text-center text-gray-800 mb-12">
              Upload Your Documents
            </h3>

            <div className="space-y-16">
              {/* Driving License */}
              <div>
                <h3 className="text-3xl font-bold text-green-700 mb-8 flex items-center gap-4">
                  <CheckCircle className="w-12 h-12" /> Driving License
                </h3>
                <div className="grid md:grid-cols-2 gap-10">
                  <DocCard
                    title="Driving License (Front)"
                    id="licenseFront"
                    required
                  />
                  <DocCard
                    title="Driving License (Back)"
                    id="licenseBack"
                    required
                  />
                </div>
              </div>

              {/* Other Documents */}
              <div>
                <h3 className="text-3xl font-bold text-blue-700 mb-8 flex items-center gap-4">
                  <FileText className="w-12 h-12" /> Other Required Documents
                </h3>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
                  <DocCard title="PAN Card" id="panCard" required />
                  <DocCard title="Aadhaar Front" id="aadhaarFront" required />
                  <DocCard title="Aadhaar Back" id="aadhaarBack" required />
                  <DocCard title="Salary Slip" id="salarySlip" />
                  <DocCard title="Form 16" id="form16" />
                  <DocCard title="Bank Statement" id="bankStatement" />
                  <DocCard title="Cancelled Cheque" id="cancelledCheque" />
                  <DocCard title="NOC from Society" id="noc" />
                </div>
              </div>
            </div>
          </div>

          {/* Form Section */}
          <div className="bg-white rounded-3xl shadow-2xl p-12">
            <h3 className="text-4xl font-bold text-center text-gray-800 mb-8">
              Additional Information
            </h3>
            <p className="text-center text-xl text-gray-600 mb-12">
              Please fill in the details below
            </p>

            <div className="grid md:grid-cols-2 gap-10 max-w-5xl mx-auto">
              <div>
                <label className="block font-bold mb-2 flex items-center gap-3">
                  <User className="w-6 h-6 text-blue-600" /> First Name *
                </label>
                <input
                  type="text"
                  value={formData.firstName}
                  onChange={(e) =>
                    setFormData({ ...formData, firstName: e.target.value })
                  }
                  className="w-full px-6 py-5 border-2 rounded-xl focus:border-blue-500 text-lg"
                  placeholder="First Name"
                />
              </div>
              <div>
                <label className="block font-bold mb-2">Last Name *</label>
                <input
                  type="text"
                  value={formData.lastName}
                  onChange={(e) =>
                    setFormData({ ...formData, lastName: e.target.value })
                  }
                  className="w-full px-6 py-5 border-2 rounded-xl focus:border-blue-500 text-lg"
                  placeholder="Last Name"
                />
              </div>
              <div>
                <label className="block font-bold mb-2 flex items-center gap-3">
                  <FileText className="w-6 h-6 text-blue-600" /> License No. *
                </label>
                <input
                  type="text"
                  value={formData.licenseNo}
                  onChange={(e) =>
                    setFormData({ ...formData, licenseNo: e.target.value })
                  }
                  className="w-full px-6 py-5 border-2 rounded-xl focus:border-blue-500 text-lg"
                  placeholder="DL Number"
                />
              </div>
              <div>
                <label className="block font-bold mb-2 flex items-center gap-3">
                  <Calendar className="w-6 h-6 text-blue-600" /> Date of Birth *
                </label>
                <DatePicker
                  selected={formData.dob}
                  onChange={(d) => setFormData({ ...formData, dob: d })}
                  className="w-full px-6 py-5 border-2 rounded-xl focus:border-blue-500 text-lg"
                  dateFormat="dd/MM/yyyy"
                  placeholderText="Select DOB"
                  showYearDropdown
                />
              </div>
              <div>
                <label className="block font-bold mb-2 flex items-center gap-3">
                  <Calendar className="w-6 h-6 text-blue-600" /> Validity Date *
                </label>
                <DatePicker
                  selected={formData.expiryDate}
                  onChange={(d) => setFormData({ ...formData, expiryDate: d })}
                  className="w-full px-6 py-5 border-2 rounded-xl focus:border-blue-500 text-lg"
                  dateFormat="dd/MM/yyyy"
                  placeholderText="Validity Date"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block font-bold mb-2 flex items-center gap-3">
                  <MapPin className="w-6 h-6 text-blue-600" /> Address *
                </label>
                <textarea
                  rows={4}
                  value={formData.address}
                  onChange={(e) =>
                    setFormData({ ...formData, address: e.target.value })
                  }
                  className="w-full px-6 py-5 border-2 rounded-xl focus:border-blue-500 text-lg"
                  placeholder="Full permanent address"
                ></textarea>
              </div>
            </div>

            <div className="text-center mt-16">
              <button className="bg-gradient-to-r from-green-600 to-emerald-700 hover:from-green-700 hover:to-emerald-800 text-white font-bold text-3xl px-48 py-10 rounded-3xl shadow-2xl transform hover:scale-105 transition duration-300">
                Submit Application
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
